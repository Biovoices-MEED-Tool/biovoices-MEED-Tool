--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.spring_session_attributes DROP CONSTRAINT spring_session_attributes_fk;
ALTER TABLE ONLY public.agenda_join_setting_the_scene_agenda_items DROP CONSTRAINT fkngayl8gd0mwvfxd376eusv684;
ALTER TABLE ONLY public.agenda_join_working_phase_agenda_items DROP CONSTRAINT fkmqcyjh5ri4sitfkj8bt5cp1dx;
ALTER TABLE ONLY public.activity_join_sources DROP CONSTRAINT fkkqeam3w8qlkdvaar3kplc5es7;
ALTER TABLE ONLY public.agenda_join_working_phase_agenda_items DROP CONSTRAINT fkhnj58xvr7jm7ikxwkhh4x5ynh;
ALTER TABLE ONLY public.agenda_join_wrap_up_agenda_items DROP CONSTRAINT fkgbfuhvs56rfd4o1i0p27e8xm7;
ALTER TABLE ONLY public.agenda_join_wrap_up_agenda_items DROP CONSTRAINT fkbr09lys5wd4q7s3mv28rxeo1i;
ALTER TABLE ONLY public.agenda DROP CONSTRAINT fkbetqx1g1esby6x8heckpr5opx;
ALTER TABLE ONLY public.agenda_join_setting_the_scene_agenda_items DROP CONSTRAINT fk7ltvpuwkh77s26ays966elvwt;
ALTER TABLE ONLY public.activity_join_sources DROP CONSTRAINT fk2pr9dausytjc6lhxcds0gpc1h;
DROP INDEX public.spring_session_ix3;
DROP INDEX public.spring_session_ix2;
DROP INDEX public.spring_session_ix1;
ALTER TABLE ONLY public.agenda_join_working_phase_agenda_items DROP CONSTRAINT uk_obbc4dc8bph2gp5eqs6aohyhb;
ALTER TABLE ONLY public.activity_join_sources DROP CONSTRAINT uk_h7ajl1vxue8y8xradumjomkqa;
ALTER TABLE ONLY public.agenda_join_setting_the_scene_agenda_items DROP CONSTRAINT uk_dpkbb42ooo0e9cl89h69wc8k0;
ALTER TABLE ONLY public.agenda_join_wrap_up_agenda_items DROP CONSTRAINT uk_b4xh7hcs73wp250v48ecujv2w;
ALTER TABLE ONLY public.spring_session DROP CONSTRAINT spring_session_pk;
ALTER TABLE ONLY public.spring_session_attributes DROP CONSTRAINT spring_session_attributes_pk;
ALTER TABLE ONLY public.source DROP CONSTRAINT source_pkey;
ALTER TABLE ONLY public.old_matrixb DROP CONSTRAINT old_matrixb_pkey;
ALTER TABLE ONLY public.old_matrixa DROP CONSTRAINT old_matrixa_pkey;
ALTER TABLE ONLY public.matrixb DROP CONSTRAINT matrixb_pkey;
ALTER TABLE ONLY public.matrixa DROP CONSTRAINT matrixa_pkey;
ALTER TABLE ONLY public.fact_sheet DROP CONSTRAINT fact_sheet_pkey;
ALTER TABLE ONLY public.agenda DROP CONSTRAINT agenda_pkey;
ALTER TABLE ONLY public.agenda_item DROP CONSTRAINT agenda_item_pkey;
ALTER TABLE ONLY public.activity DROP CONSTRAINT activity_pkey;
DROP TABLE public.spring_session_attributes;
DROP TABLE public.spring_session;
DROP TABLE public.source;
DROP TABLE public.old_matrixb;
DROP TABLE public.old_matrixa;
DROP TABLE public.matrixb;
DROP TABLE public.matrixa;
DROP SEQUENCE public.hibernate_sequence;
DROP TABLE public.fact_sheet;
DROP TABLE public.agenda_join_wrap_up_agenda_items;
DROP TABLE public.agenda_join_working_phase_agenda_items;
DROP TABLE public.agenda_join_setting_the_scene_agenda_items;
DROP TABLE public.agenda_item;
DROP TABLE public.agenda;
DROP TABLE public.activity_join_sources;
DROP TABLE public.activity;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: activity; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE activity (
    id bigint NOT NULL,
    brief_description text,
    composition_of_audience character varying(255),
    experience_level_required text,
    level_of_complexity_and_possible_challenges text,
    methodology text,
    name character varying(255),
    number_of_audience character varying(255),
    objective text,
    picture text,
    planning_time character varying(255),
    relevant_sources text,
    time_estimated character varying(255)
);


ALTER TABLE public.activity OWNER TO postgres;

--
-- Name: activity_join_sources; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE activity_join_sources (
    activity_id bigint NOT NULL,
    source_id bigint NOT NULL
);


ALTER TABLE public.activity_join_sources OWNER TO postgres;

--
-- Name: agenda; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE agenda (
    id bigint NOT NULL,
    fact_sheet bigint
);


ALTER TABLE public.agenda OWNER TO postgres;

--
-- Name: agenda_item; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE agenda_item (
    id bigint NOT NULL,
    description character varying(255),
    name character varying(255)
);


ALTER TABLE public.agenda_item OWNER TO postgres;

--
-- Name: agenda_join_setting_the_scene_agenda_items; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE agenda_join_setting_the_scene_agenda_items (
    agenda_id bigint NOT NULL,
    agenda_item_id bigint NOT NULL
);


ALTER TABLE public.agenda_join_setting_the_scene_agenda_items OWNER TO postgres;

--
-- Name: agenda_join_working_phase_agenda_items; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE agenda_join_working_phase_agenda_items (
    agenda_id bigint NOT NULL,
    agenda_item_id bigint NOT NULL
);


ALTER TABLE public.agenda_join_working_phase_agenda_items OWNER TO postgres;

--
-- Name: agenda_join_wrap_up_agenda_items; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE agenda_join_wrap_up_agenda_items (
    agenda_id bigint NOT NULL,
    agenda_item_id bigint NOT NULL
);


ALTER TABLE public.agenda_join_wrap_up_agenda_items OWNER TO postgres;

--
-- Name: fact_sheet; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fact_sheet (
    id bigint NOT NULL,
    brief_description text,
    budget character varying(255),
    example text,
    facilitator_skills character varying(255),
    group_composition character varying(255),
    level_of_knowledge_required text,
    methodology text,
    name character varying(255),
    number_of_audience character varying(255),
    objective text,
    planning_time character varying(255),
    relevant_sources text,
    target_audience character varying(255),
    time_estimated character varying(255)
);


ALTER TABLE public.fact_sheet OWNER TO postgres;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO postgres;

--
-- Name: matrixa; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE matrixa (
    id bigint NOT NULL,
    determining_factor character varying(255),
    mml_format character varying(255),
    score double precision NOT NULL,
    value character varying(255),
    color character varying(255)
);


ALTER TABLE public.matrixa OWNER TO postgres;

--
-- Name: matrixb; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE matrixb (
    id bigint NOT NULL,
    activity character varying(255),
    mml_format_face character varying(255),
    score double precision NOT NULL,
    type character varying(255),
    value character varying(255),
    color character varying(255)
);


ALTER TABLE public.matrixb OWNER TO postgres;

--
-- Name: old_matrixa; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE old_matrixa (
    id bigint NOT NULL,
    determining_factor character varying(255),
    mml_format character varying(255),
    score double precision NOT NULL,
    value character varying(255),
    color character varying(255)
);


ALTER TABLE public.old_matrixa OWNER TO postgres;

--
-- Name: old_matrixb; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE old_matrixb (
    id bigint NOT NULL,
    activity character varying(255),
    factor character varying(255),
    mml_format_face character varying(255),
    score double precision NOT NULL,
    type character varying(255),
    value character varying(255),
    color character varying(255)
);


ALTER TABLE public.old_matrixb OWNER TO postgres;

--
-- Name: source; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE source (
    id bigint NOT NULL,
    picture character varying(255),
    title character varying(255),
    url character varying(255)
);


ALTER TABLE public.source OWNER TO postgres;

--
-- Name: spring_session; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE spring_session (
    primary_id character(36) NOT NULL,
    session_id character(36) NOT NULL,
    creation_time bigint NOT NULL,
    last_access_time bigint NOT NULL,
    max_inactive_interval integer NOT NULL,
    expiry_time bigint NOT NULL,
    principal_name character varying(100)
);


ALTER TABLE public.spring_session OWNER TO postgres;

--
-- Name: spring_session_attributes; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE spring_session_attributes (
    session_primary_id character(36) NOT NULL,
    attribute_name character varying(200) NOT NULL,
    attribute_bytes bytea NOT NULL
);


ALTER TABLE public.spring_session_attributes OWNER TO postgres;

--
-- Data for Name: activity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY activity (id, brief_description, composition_of_audience, experience_level_required, level_of_complexity_and_possible_challenges, methodology, name, number_of_audience, objective, picture, planning_time, relevant_sources, time_estimated) FROM stdin;
\.
COPY activity (id, brief_description, composition_of_audience, experience_level_required, level_of_complexity_and_possible_challenges, methodology, name, number_of_audience, objective, picture, planning_time, relevant_sources, time_estimated) FROM '$$PATH$$/2944.dat';

--
-- Data for Name: activity_join_sources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY activity_join_sources (activity_id, source_id) FROM stdin;
\.
COPY activity_join_sources (activity_id, source_id) FROM '$$PATH$$/2945.dat';

--
-- Data for Name: agenda; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY agenda (id, fact_sheet) FROM stdin;
\.
COPY agenda (id, fact_sheet) FROM '$$PATH$$/2946.dat';

--
-- Data for Name: agenda_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY agenda_item (id, description, name) FROM stdin;
\.
COPY agenda_item (id, description, name) FROM '$$PATH$$/2947.dat';

--
-- Data for Name: agenda_join_setting_the_scene_agenda_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY agenda_join_setting_the_scene_agenda_items (agenda_id, agenda_item_id) FROM stdin;
\.
COPY agenda_join_setting_the_scene_agenda_items (agenda_id, agenda_item_id) FROM '$$PATH$$/2948.dat';

--
-- Data for Name: agenda_join_working_phase_agenda_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY agenda_join_working_phase_agenda_items (agenda_id, agenda_item_id) FROM stdin;
\.
COPY agenda_join_working_phase_agenda_items (agenda_id, agenda_item_id) FROM '$$PATH$$/2949.dat';

--
-- Data for Name: agenda_join_wrap_up_agenda_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY agenda_join_wrap_up_agenda_items (agenda_id, agenda_item_id) FROM stdin;
\.
COPY agenda_join_wrap_up_agenda_items (agenda_id, agenda_item_id) FROM '$$PATH$$/2950.dat';

--
-- Data for Name: fact_sheet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY fact_sheet (id, brief_description, budget, example, facilitator_skills, group_composition, level_of_knowledge_required, methodology, name, number_of_audience, objective, planning_time, relevant_sources, target_audience, time_estimated) FROM stdin;
\.
COPY fact_sheet (id, brief_description, budget, example, facilitator_skills, group_composition, level_of_knowledge_required, methodology, name, number_of_audience, objective, planning_time, relevant_sources, target_audience, time_estimated) FROM '$$PATH$$/2951.dat';

--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('hibernate_sequence', 1, false);


--
-- Data for Name: matrixa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY matrixa (id, determining_factor, mml_format, score, value, color) FROM stdin;
\.
COPY matrixa (id, determining_factor, mml_format, score, value, color) FROM '$$PATH$$/2953.dat';

--
-- Data for Name: matrixb; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY matrixb (id, activity, mml_format_face, score, type, value, color) FROM stdin;
\.
COPY matrixb (id, activity, mml_format_face, score, type, value, color) FROM '$$PATH$$/2954.dat';

--
-- Data for Name: old_matrixa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY old_matrixa (id, determining_factor, mml_format, score, value, color) FROM stdin;
\.
COPY old_matrixa (id, determining_factor, mml_format, score, value, color) FROM '$$PATH$$/2955.dat';

--
-- Data for Name: old_matrixb; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY old_matrixb (id, activity, factor, mml_format_face, score, type, value, color) FROM stdin;
\.
COPY old_matrixb (id, activity, factor, mml_format_face, score, type, value, color) FROM '$$PATH$$/2956.dat';

--
-- Data for Name: source; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY source (id, picture, title, url) FROM stdin;
\.
COPY source (id, picture, title, url) FROM '$$PATH$$/2957.dat';

--
-- Data for Name: spring_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY spring_session (primary_id, session_id, creation_time, last_access_time, max_inactive_interval, expiry_time, principal_name) FROM stdin;
\.
COPY spring_session (primary_id, session_id, creation_time, last_access_time, max_inactive_interval, expiry_time, principal_name) FROM '$$PATH$$/2958.dat';

--
-- Data for Name: spring_session_attributes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY spring_session_attributes (session_primary_id, attribute_name, attribute_bytes) FROM stdin;
\.
COPY spring_session_attributes (session_primary_id, attribute_name, attribute_bytes) FROM '$$PATH$$/2959.dat';

--
-- Name: activity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY activity
    ADD CONSTRAINT activity_pkey PRIMARY KEY (id);


--
-- Name: agenda_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY agenda_item
    ADD CONSTRAINT agenda_item_pkey PRIMARY KEY (id);


--
-- Name: agenda_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY agenda
    ADD CONSTRAINT agenda_pkey PRIMARY KEY (id);


--
-- Name: fact_sheet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fact_sheet
    ADD CONSTRAINT fact_sheet_pkey PRIMARY KEY (id);


--
-- Name: matrixa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY matrixa
    ADD CONSTRAINT matrixa_pkey PRIMARY KEY (id);


--
-- Name: matrixb_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY matrixb
    ADD CONSTRAINT matrixb_pkey PRIMARY KEY (id);


--
-- Name: old_matrixa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY old_matrixa
    ADD CONSTRAINT old_matrixa_pkey PRIMARY KEY (id);


--
-- Name: old_matrixb_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY old_matrixb
    ADD CONSTRAINT old_matrixb_pkey PRIMARY KEY (id);


--
-- Name: source_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY source
    ADD CONSTRAINT source_pkey PRIMARY KEY (id);


--
-- Name: spring_session_attributes_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY spring_session_attributes
    ADD CONSTRAINT spring_session_attributes_pk PRIMARY KEY (session_primary_id, attribute_name);


--
-- Name: spring_session_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY spring_session
    ADD CONSTRAINT spring_session_pk PRIMARY KEY (primary_id);


--
-- Name: uk_b4xh7hcs73wp250v48ecujv2w; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY agenda_join_wrap_up_agenda_items
    ADD CONSTRAINT uk_b4xh7hcs73wp250v48ecujv2w UNIQUE (agenda_item_id);


--
-- Name: uk_dpkbb42ooo0e9cl89h69wc8k0; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY agenda_join_setting_the_scene_agenda_items
    ADD CONSTRAINT uk_dpkbb42ooo0e9cl89h69wc8k0 UNIQUE (agenda_item_id);


--
-- Name: uk_h7ajl1vxue8y8xradumjomkqa; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY activity_join_sources
    ADD CONSTRAINT uk_h7ajl1vxue8y8xradumjomkqa UNIQUE (source_id);


--
-- Name: uk_obbc4dc8bph2gp5eqs6aohyhb; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY agenda_join_working_phase_agenda_items
    ADD CONSTRAINT uk_obbc4dc8bph2gp5eqs6aohyhb UNIQUE (agenda_item_id);


--
-- Name: spring_session_ix1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX spring_session_ix1 ON spring_session USING btree (session_id);


--
-- Name: spring_session_ix2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX spring_session_ix2 ON spring_session USING btree (expiry_time);


--
-- Name: spring_session_ix3; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX spring_session_ix3 ON spring_session USING btree (principal_name);


--
-- Name: fk2pr9dausytjc6lhxcds0gpc1h; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY activity_join_sources
    ADD CONSTRAINT fk2pr9dausytjc6lhxcds0gpc1h FOREIGN KEY (source_id) REFERENCES source(id);


--
-- Name: fk7ltvpuwkh77s26ays966elvwt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY agenda_join_setting_the_scene_agenda_items
    ADD CONSTRAINT fk7ltvpuwkh77s26ays966elvwt FOREIGN KEY (agenda_id) REFERENCES agenda(id);


--
-- Name: fkbetqx1g1esby6x8heckpr5opx; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY agenda
    ADD CONSTRAINT fkbetqx1g1esby6x8heckpr5opx FOREIGN KEY (fact_sheet) REFERENCES fact_sheet(id);


--
-- Name: fkbr09lys5wd4q7s3mv28rxeo1i; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY agenda_join_wrap_up_agenda_items
    ADD CONSTRAINT fkbr09lys5wd4q7s3mv28rxeo1i FOREIGN KEY (agenda_id) REFERENCES agenda(id);


--
-- Name: fkgbfuhvs56rfd4o1i0p27e8xm7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY agenda_join_wrap_up_agenda_items
    ADD CONSTRAINT fkgbfuhvs56rfd4o1i0p27e8xm7 FOREIGN KEY (agenda_item_id) REFERENCES agenda_item(id);


--
-- Name: fkhnj58xvr7jm7ikxwkhh4x5ynh; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY agenda_join_working_phase_agenda_items
    ADD CONSTRAINT fkhnj58xvr7jm7ikxwkhh4x5ynh FOREIGN KEY (agenda_id) REFERENCES agenda(id);


--
-- Name: fkkqeam3w8qlkdvaar3kplc5es7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY activity_join_sources
    ADD CONSTRAINT fkkqeam3w8qlkdvaar3kplc5es7 FOREIGN KEY (activity_id) REFERENCES activity(id);


--
-- Name: fkmqcyjh5ri4sitfkj8bt5cp1dx; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY agenda_join_working_phase_agenda_items
    ADD CONSTRAINT fkmqcyjh5ri4sitfkj8bt5cp1dx FOREIGN KEY (agenda_item_id) REFERENCES agenda_item(id);


--
-- Name: fkngayl8gd0mwvfxd376eusv684; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY agenda_join_setting_the_scene_agenda_items
    ADD CONSTRAINT fkngayl8gd0mwvfxd376eusv684 FOREIGN KEY (agenda_item_id) REFERENCES agenda_item(id);


--
-- Name: spring_session_attributes_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY spring_session_attributes
    ADD CONSTRAINT spring_session_attributes_fk FOREIGN KEY (session_primary_id) REFERENCES spring_session(primary_id) ON DELETE CASCADE;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

